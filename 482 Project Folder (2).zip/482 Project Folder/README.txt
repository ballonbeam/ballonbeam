For the  Simulink Models, Use PID482.m to load variables into the Workspace. This will show a working 
function in simulink.

For the VREP model, run BallBalancer3.ttt and then run Test.m. The distance from the ball to the proximity sensor
should be sent to MatLab.